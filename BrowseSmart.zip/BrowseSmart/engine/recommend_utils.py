### recommend_utils.py ###
import os
import pymongo
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv

load_dotenv()

# Connect to MongoDB
client = pymongo.MongoClient(os.getenv("MONGO_URI"))
db = client["BrowseSmart"]
collection = db["Content_combined"]

# Load data from MongoDB
movies_data = list(collection.find({}, {"_id": 0}))
movies_df = pd.DataFrame(movies_data)

# Replace missing 'tags' column or NaNs with empty string
if 'tags' not in movies_df.columns:
    movies_df['tags'] = ''

movies_df['tags'] = movies_df['tags'].fillna('')
movies_df = movies_df[movies_df['tags'].str.strip() != '']
movies_df['tags'] = movies_df['tags'].apply(lambda x: x.lower() if isinstance(x, str) else '')

# Vectorize tags
cv = CountVectorizer(max_features=5000, stop_words='english')
vectors = cv.fit_transform(movies_df['tags']).toarray()
similarity = cosine_similarity(vectors)

def recommend_movies(title):
    title = title.lower()
    matched = movies_df[movies_df['title'].str.lower() == title]

    if matched.empty:
        return []

    idx = matched.index[0]
    distances = list(enumerate(similarity[idx]))
    sorted_distances = sorted(distances, key=lambda x: x[1], reverse=True)[1:11]

    recommendations = []
    for i in sorted_distances:
        movie = movies_df.iloc[i[0]]
        recommendations.append({
            "title": movie.get('title', ''),
            "poster_path": movie.get('poster_path', ''),
            "overview": movie.get('overview', ''),
            "genres": movie.get('genres', ''),
            "cast": movie.get('cast', ''),
            "crew": movie.get('crew', '')
        })

    return recommendations

# Debugging info
print(f"[INFO] Loaded {len(movies_df)} valid movies with tags.")
print("[INFO] Sample tags:")
print(movies_df['tags'].head())
