const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
    id: Number,
    title: String,
    overview: String,
    genres: Array,
    cast: Array,
    crew: Array,
    keywords: Array,
    poster_path: String,
    tags: String
}, { collection: 'movies_combined' });  // Exact MongoDB collection name

module.exports = mongoose.model('Movie', movieSchema);
