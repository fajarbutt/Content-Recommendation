# add_posters.py

import pandas as pd
import requests
import time

# Load your dataset
df = pd.read_csv('../data/tmdb_5000_movies.csv')  # Adjust if needed
api_key = "19b999806c9990d915be170d9a4e11a1"  # TMDB API key

# Function to fetch poster_path using TMDB API
def get_poster_path(title):
    try:
        response = requests.get(
            "https://api.themoviedb.org/3/search/movie",
            params={"api_key": api_key, "query": title}
        )
        data = response.json()
        if data['results']:
            return data['results'][0]['poster_path']
        else:
            return None
    except Exception as e:
        print(f"Error fetching for {title}: {e}")
        return None

# Add poster_path to DataFrame with delay to avoid API rate limits
poster_paths = []
for idx, title in enumerate(df['title']):
    print(f"[{idx+1}/{len(df)}] Fetching poster for: {title}")
    poster_paths.append(get_poster_path(title))
    time.sleep(0.25)  # Add delay to avoid hitting rate limits

df['poster_path'] = poster_paths

# Save updated CSV
df.to_csv('../data/tmdb_5000_movies_with_posters.csv', index=False)
print("✅ Poster paths added and CSV saved as 'tmdb_5000_movies_with_posters.csv'")
