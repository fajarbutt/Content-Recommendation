import pandas as pd
from pymongo import MongoClient
import json
import ast

# Load the data
movies_df = pd.read_csv('../data/tmdb_5000_movies_with_posters.csv')
credits_df = pd.read_csv('../data/tmdb_5000_credits.csv')

# Merge movies and credits
merged_df = movies_df.merge(credits_df, on='title')

# Helper functions
def extract_names(obj_str, key):
    try:
        parsed = ast.literal_eval(obj_str)
        return " ".join(item[key] for item in parsed[:5])  # top 5 items
    except Exception:
        return ""

def get_director(crew_str):
    try:
        crew = ast.literal_eval(crew_str)
        for person in crew:
            if person['job'].lower() == 'director':
                return person['name']
        return ""
    except Exception:
        return ""

# Clean/process fields
merged_df['genres'] = merged_df['genres'].apply(lambda x: extract_names(x, 'name'))
merged_df['keywords'] = merged_df['keywords'].apply(lambda x: extract_names(x, 'name'))
merged_df['cast'] = merged_df['cast'].apply(lambda x: extract_names(x, 'name'))
merged_df['crew'] = merged_df['crew'].apply(get_director)
merged_df['overview'] = merged_df['overview'].fillna('')

# Create tags
merged_df['tags'] = (
    merged_df['overview'] + ' ' +
    merged_df['genres'] + ' ' +
    merged_df['keywords'] + ' ' +
    merged_df['cast'] + ' ' +
    merged_df['crew']
).str.lower()

# ✅ Now keep all desired fields
final_df = merged_df[[
    'title', 'overview', 'genres', 'keywords',
    'cast', 'crew', 'poster_path', 'tags'
]]

# Remove invalid entries
final_df = final_df[final_df['tags'].str.strip().astype(bool)]
final_df = final_df[final_df['title'].str.strip().astype(bool)]

# Upload to MongoDB
records = json.loads(final_df.to_json(orient='records'))
client = MongoClient('mongodb://localhost:27017/')
db = client['BrowseSmart']
collection = db['Content_combined']

collection.drop()  # optional: reset the collection
collection.insert_many(records)

print(f"✅ Uploaded {len(records)} content with full attributes to MongoDB.")
